import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { ArrowLeft, AlertCircle } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import Auth from "@/pages/Auth";

interface JourneyAuthScreenProps {
  onContinue: (method: "google" | "apple" | "anonymous" | "email") => void;
  onRegister: () => void;
  onBack: () => void;
}

const JourneyAuthScreen = ({ onContinue, onRegister, onBack }: JourneyAuthScreenProps) => {
  const navigate = useNavigate();
  const { signInWithGoogle, signInWithApple, signInAnonymously } = useAuth();
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState(false);
  const [showError, setShowError] = useState(false);
  const [isLoading, setIsLoading] = useState<string | null>(null);
  const [authMode, setAuthMode] = useState<"main" | "email-signin" | "email-signup">("main");

  const handleGoogleAuth = async () => {
    if (!hasAcceptedTerms) {
      setShowError(true);
      return;
    }
    
    setIsLoading("google");
    localStorage.setItem("termsAcceptedAt", new Date().toISOString());
    
    const { error } = await signInWithGoogle();
    if (error) {
      toast.error("Something went wrong. Please try again.");
      setIsLoading(null);
    }
    // OAuth redirects, so no need to handle success here
  };

  const handleAppleAuth = async () => {
    if (!hasAcceptedTerms) {
      setShowError(true);
      return;
    }
    
    setIsLoading("apple");
    localStorage.setItem("termsAcceptedAt", new Date().toISOString());
    
    const { error } = await signInWithApple();
    if (error) {
      toast.error("Something went wrong. Please try again.");
      setIsLoading(null);
    }
    // OAuth redirects, so no need to handle success here
  };

  const handleAnonymousAuth = async () => {
    if (!hasAcceptedTerms) {
      setShowError(true);
      return;
    }
    
    setIsLoading("anonymous");
    localStorage.setItem("termsAcceptedAt", new Date().toISOString());
    
    const { error } = await signInAnonymously();
    if (error) {
      toast.error("Something went wrong. Please try again.");
      setIsLoading(null);
    } else {
      onContinue("anonymous");
    }
  };

  const handleEmailAuth = () => {
    if (!hasAcceptedTerms) {
      setShowError(true);
      return;
    }
    localStorage.setItem("termsAcceptedAt", new Date().toISOString());
    setAuthMode("email-signin");
  };

  const handleRegister = () => {
    if (!hasAcceptedTerms) {
      setShowError(true);
      return;
    }
    localStorage.setItem("termsAcceptedAt", new Date().toISOString());
    setAuthMode("email-signup");
  };

  const handleEmailSuccess = () => {
    onContinue("email");
  };

  // Show email auth screen
  if (authMode === "email-signin" || authMode === "email-signup") {
    return (
      <Auth 
        mode={authMode === "email-signin" ? "signin" : "signup"}
        onBack={() => setAuthMode("main")}
        onSuccess={handleEmailSuccess}
      />
    );
  }

  return (
    <div className="min-h-screen gradient-bg flex flex-col">
      {/* Header with back button */}
      <div className="h-14 sm:h-16 flex items-center px-4">
        <button
          onClick={onBack}
          className="p-2 -ml-2 text-foreground/70 hover:text-foreground transition-colors rounded-lg hover:bg-secondary/30"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
      </div>

      {/* Main content */}
      <main className="flex-1 flex flex-col justify-center px-4 sm:px-6 pb-8 max-w-lg mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-10 opacity-0 animate-fade-in" style={{ animationFillMode: "forwards" }}>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-4 leading-tight">
            Let's start your journey
          </h1>
          <p className="text-soft text-base sm:text-lg leading-relaxed">
            Choose how you'd like to continue. You can stay anonymous if you prefer.
          </p>
        </div>

        {/* Auth buttons */}
        <div 
          className="flex flex-col gap-3 opacity-0 animate-fade-in"
          style={{ animationDelay: "200ms", animationFillMode: "forwards" }}
        >
          {/* Google - disabled until provider is configured */}
          <button
            disabled={true}
            className={cn(
              "w-full py-4 px-6 text-base font-medium rounded-xl transition-all duration-300",
              "bg-card border border-border/50 text-foreground",
              "flex items-center justify-center gap-3",
              "opacity-40 cursor-not-allowed"
            )}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            Continue with Google
          </button>

          {/* Apple - disabled until provider is configured */}
          <button
            disabled={true}
            className={cn(
              "w-full py-4 px-6 text-base font-medium rounded-xl transition-all duration-300",
              "bg-card border border-border/50 text-foreground",
              "flex items-center justify-center gap-3",
              "opacity-40 cursor-not-allowed"
            )}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
            </svg>
            Continue with Apple
          </button>

          {/* Helper text for disabled OAuth */}
          <p className="text-xs text-muted-foreground text-center px-2">
            Google and Apple sign-in will be available shortly.
          </p>

          {/* Anonymous */}
          <button
            onClick={handleAnonymousAuth}
            disabled={isLoading !== null}
            className={cn(
              "w-full py-4 px-6 text-base font-medium rounded-xl transition-all duration-300",
              "bg-card border border-border/50 text-foreground",
              "hover:border-primary/40 hover:bg-secondary/30 hover:scale-[1.01]",
              "active:scale-[0.99]",
              "flex items-center justify-center gap-3",
              "disabled:opacity-60 disabled:cursor-not-allowed",
              !hasAcceptedTerms && "opacity-60"
            )}
          >
            {isLoading === "anonymous" ? (
              <span className="animate-pulse">Setting up...</span>
            ) : (
              <>
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
                Continue anonymously
              </>
            )}
          </button>

          {/* Anonymous warning */}
          <div className="flex items-start gap-2 px-2 py-2 rounded-lg bg-secondary/20 border border-border/30">
            <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              Anonymous data is stored locally only. If you delete the app, your data will be lost.
            </p>
          </div>

          {/* Email sign in */}
          <button
            onClick={handleEmailAuth}
            disabled={isLoading !== null}
            className={cn(
              "w-full py-4 px-6 text-base font-medium rounded-xl transition-all duration-300",
              "bg-card border border-border/50 text-foreground",
              "hover:border-primary/40 hover:bg-secondary/30 hover:scale-[1.01]",
              "active:scale-[0.99]",
              "flex items-center justify-center gap-3",
              "disabled:opacity-60 disabled:cursor-not-allowed",
              !hasAcceptedTerms && "opacity-60"
            )}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect width="20" height="16" x="2" y="4" rx="2" />
              <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
            </svg>
            Sign in with email
          </button>
        </div>

        {/* Legal acceptance */}
        <div 
          className="mt-6 opacity-0 animate-fade-in"
          style={{ animationDelay: "300ms", animationFillMode: "forwards" }}
        >
          <div className="flex items-start gap-3">
            <Checkbox
              id="terms"
              checked={hasAcceptedTerms}
              onCheckedChange={(checked) => {
                setHasAcceptedTerms(checked === true);
                if (checked) setShowError(false);
              }}
              className="mt-0.5"
            />
            <label htmlFor="terms" className="text-sm text-foreground/90 leading-relaxed cursor-pointer">
              I agree to the{" "}
              <button
                type="button"
                onClick={() => navigate("/privacy-policy")}
                className="text-primary hover:text-primary/80 underline underline-offset-2"
              >
                Privacy Policy
              </button>
              {" "}and{" "}
              <button
                type="button"
                onClick={() => navigate("/terms-of-use")}
                className="text-primary hover:text-primary/80 underline underline-offset-2"
              >
                Terms of Use
              </button>
            </label>
          </div>
          <p className="text-xs text-muted-foreground mt-2 ml-7">
            You can review how your data is handled before continuing.
          </p>
          {showError && (
            <p className="text-sm text-destructive mt-3 ml-7">
              Please review and accept the Privacy Policy and Terms of Use to continue.
            </p>
          )}
        </div>

        {/* Register link */}
        <div 
          className="text-center mt-8 opacity-0 animate-fade-in"
          style={{ animationDelay: "400ms", animationFillMode: "forwards" }}
        >
          <p className="text-soft text-sm">
            Don't have an account?{" "}
            <button
              onClick={handleRegister}
              className="text-primary hover:text-primary/80 font-medium transition-colors underline-offset-4 hover:underline"
            >
              Register
            </button>
          </p>
        </div>
      </main>
    </div>
  );
};

export default JourneyAuthScreen;
